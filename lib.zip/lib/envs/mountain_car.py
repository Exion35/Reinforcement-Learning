import numpy as np
import gym
from gym import spaces


class MountainCar(gym.Env):
    def __init__(self, position_min=-1.2, position_max=0.5, velocity_min=-0.07, velocity_max=0.07):
        
        self.observation_space = spaces.Box(np.array([position_min, velocity_min]),
                                            np.array([position_max, velocity_max]))
        # self.observation_space = spaces.Tuple(spaces.Box(position_min, position_max),
        #                                       spaces.Box(velocity_min, velocity_max))
        self.action_space = spaces.Discrete(3)
        
        self.position_min = position_min
        self.position_max = position_max
        self.velocity_min = velocity_min
        self.velocity_max = velocity_max

        self.actions = np.array([-1, 0, 1])
        self.reset()

    def reset(self):
        self.position = np.random.uniform(low=self.position_min, high=self.position_max)
        self.velocity = np.random.uniform(low=self.velocity_min, high=self.velocity_max)
        
        return (self.position, self.velocity)

    def step(self, action):
        """Given an action, move the car.

        Makes sure that position and velocity stay within specified bounds.
        Updates self.game_over if the right position bound is reached.

        @param action: an integer representing one of three actions
            -1 = full throttle reverse
             0 = zero throttle
             1 = full throttle forward

        @return reward: a float always valuing -1

        """
        if action not in self.actions:
            raise ValueError("The action value (", action, ") should be one of", self.actions)
        self.velocity = self.velocity + 0.001 * action - 0.0025 * np.cos(3 * self.position)
        self.velocity = np.clip(self.velocity, a_min=self.velocity_min, a_max=self.velocity_max)

        self.position = self.position + self.velocity
        self.position = np.clip(self.position, a_min=self.position_min, a_max=self.position_max)
        done = False
        if self.position == self.position_min:
            self.velocity = 0
        if self.position == self.position_max:
            done = True
            
        reward = -1.0
        return (self.position, self.velocity), reward, done, {}
