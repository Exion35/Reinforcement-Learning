import gym
import numpy as np
import sys
from io import StringIO
from gym import spaces


class WindyGridworldEnv(gym.Env):

    metadata = {'render.modes': ['human', 'ansi']}

    def _limit_coordinates(self, coord):
        coord[0] = min(coord[0], self.shape[0] - 1)
        coord[0] = max(coord[0], 0)
        coord[1] = min(coord[1], self.shape[1] - 1)
        coord[1] = max(coord[1], 0)
        return coord

    def __init__(self, nA):
        # Create state and action space
        self.shape = (7, 10)
        self.nS = np.prod(self.shape)
        self.action_space = spaces.Discrete(nA)
        self.observation_space = spaces.Tuple((spaces.Discrete(self.shape[0]),
               spaces.Discrete(self.shape[1])))
        
        # Define actions, 4 or 8 moves (king's moves) depending on input
        if nA == 4:
            self.actions = [[1, 0], [0, 1], [-1, 0], [0, -1]]
        elif nA == 8:
            self.actions = [[1, 0], [0, 1], [-1, 0], [0, -1], 
                            [1, 1], [-1, 1], [-1, -1], [1, -1]]
                
                                         
        # Wind strength
        self.winds = np.zeros(self.shape)
        self.winds[:,[3,4,5,8]] = 1
        self.winds[:,[6,7]] = 2
       
        self.reset()
        
    def reset(self):
        # Set location back to initial position
        self.location = (3,0)
        return self.location
        
    def step(self, action):
        assert self.action_space.contains(action)
        
        # Current location and action vector
        current = self.location
        delta = self.actions[action]
        
        # Obtain new poistion
        new_position = np.array(current) + np.array(delta) + np.array([1, 0]) * self.winds[tuple(current)]
        new_position = self._limit_coordinates(new_position).astype(int)
        self.location = tuple(new_position)

        # Determine if we are in final state
        is_done = self.location == (3, 7)
        
        return self.location, -1, is_done, {}
               
    def render(self, mode='human', close=False):
        if close:
            return

        outfile = StringIO() if mode == 'ansi' else sys.stdout
        for s1 in range(self.shape[0]-1, -1, -1):
            for s2 in range(self.shape[1]):
                # position = np.unravel_index(s, self.shape)
                position = (s1, s2)
                if self.location == position:
                    output = " x "
                elif position == (3,7):
                    output = " T "
                else:
                    output = " o "
    
                if position[1] == 0:
                    output = output.lstrip()
                if position[1] == self.shape[1] - 1:
                    output = output.rstrip()
                    output += "\n"
    
                outfile.write(output)
        outfile.write("\n")
