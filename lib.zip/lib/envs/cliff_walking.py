import numpy as np
import sys
from io import StringIO
import gym
from gym import spaces


class CliffWalkingEnv(gym.Env):

    metadata = {'render.modes': ['human', 'ansi']}

    def _limit_coordinates(self, coord):
        coord[0] = min(coord[0], self.shape[0] - 1)
        coord[0] = max(coord[0], 0)
        coord[1] = min(coord[1], self.shape[1] - 1)
        coord[1] = max(coord[1], 0)
        return coord

    def __init__(self):
        # State and action spaces
        self.shape = (4, 12)
        nS = np.prod(self.shape)
        nA = 4
        self.action_space = spaces.Discrete(nA)
        self.observation_space = spaces.Tuple((spaces.Discrete(self.shape[0]),
               spaces.Discrete(self.shape[1])))
        
        # Available actions
        self.actions = [[1, 0], [0, 1], [-1, 0], [0, -1]]

        # Cliff Location
        self._cliff = np.zeros(self.shape, dtype=bool)
        self._cliff[0, 1:-1] = True


        self.reset()

    def reset(self):
        # Set location back to initial position
        self.location = (0,0)
        return self.location
        
    def step(self, action):
        assert self.action_space.contains(action)
        
        # Current location and action vector
        current = self.location
        delta = self.actions[action]
        
        # Obtain new position
        new_position = np.array(current) + np.array(delta)
        new_position = self._limit_coordinates(new_position).astype(int)
        self.location = tuple(new_position)

        # Get reward and terminal
        reward = -100.0 if self._cliff[self.location] else -1.0
        is_done = self._cliff[self.location] or self.location == (0, 11)
        
        return self.location, reward, is_done, {}

    def render(self, mode='human', close=False):
        outfile = StringIO() if mode == 'ansi' else sys.stdout

        for s1 in range(self.shape[0]-1, -1, -1):
            for s2 in range(self.shape[1]):
                position = (s1,s2)
                if self.location == position:
                    output = " x "
                elif position == (0,11):
                    output = " T "
                elif self._cliff[position]:
                    output = " C "
                else:
                    output = " o "
        
                if position[1] == 0:
                    output = output.lstrip() 
                if position[1] == self.shape[1] - 1:
                    output = output.rstrip() 
                    output += "\n"
        
                outfile.write(output)
        outfile.write("\n")
